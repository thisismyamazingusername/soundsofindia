import SwiftUI

struct PageView: View {
    var page: Page
    
    @State private var pageIndex = 0
    private let pages: [Page] = Page.samplePages
    
    var body: some View {   
//        if (pageIndex == 0 || pageIndex == 1 || pageIndex == 2 || pageIndex == 15 || pageIndex == 16)  {
        if (pageIndex == 0) {
            VStack(spacing: 10) {
                Text(page.name)
                    .font(.title)
                Text(page.description)
                    .font(.system(size: 20, weight: .semibold, design: .default))
                    .multilineTextAlignment(.center)
                .frame(width: 500, alignment: .center)}
        }
        else {
            VStack(spacing: 2) {
                Text(page.name)
                    .font(.title)
                Image("\(page.imageUrl)")
                    .resizable()
                    .frame(width: 150, height: 100)
                    .scaledToFill()
                    .padding()
                    .cornerRadius(50)
                Text(page.description)
                    .font(.system(size: 20, weight: .semibold, design: .default))
                    .multilineTextAlignment(.center)
                    .frame(width: 500, alignment: .center)} 
        }  
    }  
}

    struct PageView_Previews: PreviewProvider {
        static var previews: some View {
            PageView(page: Page.samplePage)
        }
}
