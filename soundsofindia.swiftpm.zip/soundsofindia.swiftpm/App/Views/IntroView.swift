import SwiftUI

struct IntroView: View {
    
    @State private var pageIndex = 0
    private let pages: [Page] = Page.samplePages
   private let dotAppearance = UIPageControl.appearance()
    
    var body: some View {
        TabView(selection: $pageIndex) {
            ForEach(pages) { page in
                VStack {
                    PageView(page: page)
                    if pageIndex == 16 {
                        Button("Restart", action: goToZero)
                            .buttonStyle(.bordered)
                            .shadow(color: .backgroundColor, radius: 5, x: 0, y: 5)
                            .padding(2)
                            .foregroundColor(.white)
                        ContentView()
  
                    } else {
                        Button("Next", action: incrementPage)
                            .buttonStyle(.bordered)
                            .padding(2)
                            .foregroundColor(.white)
                            .shadow(color: .backgroundColor, radius: 5, x: 0, y: 5)
                    }
                }
                .tag(page.tag)
            }
        }
        .animation(.easeInOut, value: pageIndex) 
                .indexViewStyle(.page(backgroundDisplayMode: .interactive))
                .tabViewStyle(PageTabViewStyle())
                .onAppear {
                   dotAppearance.currentPageIndicatorTintColor = .black
                    dotAppearance.pageIndicatorTintColor = .gray
                }
    }
        
        func incrementPage() {
            pageIndex += 1
        }
        
        func goToZero() {
            pageIndex = 0
        }
        
    }
