import SwiftUI

struct BackgroundView: View {
    @State private var animateGradient: Bool = false
    var body: some View {
        ZStack{
            LinearGradient(colors: [.orange,.gray,.green], startPoint: .leading, endPoint: .trailing)
                .edgesIgnoringSafeArea(.all)
                .hueRotation(.degrees(animateGradient ? 50 : 0))
                .opacity(0.4)
                .onAppear {
                    withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) {
                        animateGradient.toggle() }
                }
        }
    }
}
