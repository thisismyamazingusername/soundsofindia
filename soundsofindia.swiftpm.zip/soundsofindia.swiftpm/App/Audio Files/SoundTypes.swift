import SwiftUI

enum AnySound {
    case bt(BTSounds)
    case d(DSounds)
    case s(SSounds)
    case f(FSounds)
    case ot(OTSounds)
}

enum BTSounds: Sound {
    case Bansuri,
    BansuriTabla1a,
    BansuriTabla1b
}

enum DSounds: Sound {
    case Dhol1,
         Dhol2a,
         Dhol2b
}

enum SSounds: Sound {
    case Sitar1a,
         Sitar1b
}

enum FSounds: Sound {
    case Fusion1a,
         Fusion1b
}

enum OTSounds: Sound {
    case Om,
         Tala
}

enum Pitch: Double {
    case D_b = 100
    case D = 200
    case E_b = 300
    case E = 400
    case F = 500
    case G_b = 600
    case G = 700
    case A_b = 800
    case A = 900
    case B_b = 1000
    case B = 1100
    case C = 1200
}
