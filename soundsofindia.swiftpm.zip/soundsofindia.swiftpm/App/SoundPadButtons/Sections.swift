import SwiftUI

struct SectionView<Content:View>: View {
    
    var sectionName: String
    let columns = [GridItem(.adaptive(minimum: 65, maximum: .infinity))]
    @ViewBuilder var content: Content
    
    var body: some View {
        VStack (spacing: 0) {
            Text(sectionName)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(.gray)
                .padding(.vertical, 5)
                .frame(maxWidth: .infinity, alignment: .center)
            LazyVGrid(columns: columns) {
                content
                    .padding(5)
                    .frame(maxHeight: .infinity, alignment: .top)
            }
            .padding(10)
            .background (
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.sectionColor)
                    .frame(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            )
            .accessibilityElement(children: .contain)
            .frame(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        }
    }
}

struct bt<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        SectionView(sectionName: "Bansuri & Tabla") {
            content
        }
    }
}

struct d<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        SectionView(sectionName: "Dhol") {
            content
        }
    }
}

struct s<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        SectionView(sectionName: "Sitar") {
            content
        }
    }
}

struct f<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        SectionView(sectionName: "Fusion") {
            content
        }
    }
}

struct ot<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        SectionView(sectionName: "Om & Tala") {
            content
        }
    }
}
