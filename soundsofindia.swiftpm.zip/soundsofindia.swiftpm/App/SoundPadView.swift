import SwiftUI

struct SoundPadView: View {
    
    
    
    var body: some View {
        HStack{
            
            VStack{
                /*#-code-walkthrough(1.exploreLoop)*/
                bt{
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(bt: .Bansuri, color: .indigo)
                    LoopButton(bt: .BansuriTabla1a, color: .white)
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(bt: .BansuriTabla1b , color: .red)
                }
                d {
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(d: .Dhol1, color: .purple)
                    LoopButton(d: .Dhol2a, color: .blue)
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(d: .Dhol2b , color: .green)
                }
            }
            VStack{
                s {
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(s: .Sitar1a, color: .orange)
                    LoopButton(s: .Sitar1b, color: .pink)
                }
                f {
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(f: .Fusion1a, color: .teal)
                    LoopButton(f: .Fusion1b, color: .white)
                    /*#-code-walkthrough(3.editSoundLook)*/
                }
                ot {
                    /*#-code-walkthrough(3.editSoundLook)*/
                    LoopButton(ot: .Om, color: .yellow)
                    LoopButton(ot: .Tala, color: .red)
                    /*#-code-walkthrough(3.editSoundLook)*/
                }
            }
        }
    }
    
}

//
