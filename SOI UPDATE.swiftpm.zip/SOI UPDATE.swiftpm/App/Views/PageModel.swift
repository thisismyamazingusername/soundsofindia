import Foundation

struct Page: Identifiable, Equatable {
    let id = UUID()
    var name: String
    var description: String
  //FIGURE OUT HOW TO PLAYSOUND (.onappear = loop sound)
   // var playSound = playSound(sound: String)
    var imageUrl: String
    var tag: Int
        
    static var samplePage = Page(name: "Title dummy", description: "Description dummy text.", imageUrl: "Image name", tag: 0) 
    
    static var samplePages: [Page] = [
        Page(name: "Hello!", description: "Teens, adults, and even children are no strangers to music. Yet, in the light of recent controversies and a shift towards more representation in pop music, there exists a problem that has yet to be addressed: the use of Asian music as backgrounds sounds in western music is exploited in order to create exotic and unique music as a growing artist base increases the competition to produce more unique music.", imageUrl: "", tag: 0),
         Page(name: "So what?", description: "The use of Asian music does help to expose Asian music to a global audience. However, whether using Asian music is deemed as 'cultural appropriation' or 'inspiration', using foreign music without understanding the stories and culture behind the origins promotes a lack of awareness regarding asian heritage to impressionable listeners.", imageUrl: "", tag: 1),
        Page(name: "Welcome to Sounds of India!", description: "In honor of the upcoming AAPI month, this app allows you to explore the stories and history of specifically India through sounds. To begin, click the next button to learn about significant instruments and sounds.", imageUrl: "", tag: 2),
        // PAGES FOR THE DESCRIPTION OF INSTRUMENT/ GENRE. 
        Page(name: "Sitar", description: "A stringed instrument with a long neck and a gourd-shaped body. It is widely associated with the Hindustani classical music tradition.", imageUrl: "Sitar", tag: 3),
        Page(name: "Tabla", description: "A pair of drums, consisting of a small drum called the dayan and a larger drum called the bayan. It is the most popular percussion instrument in Indian classical music.", imageUrl: "Tabla", tag: 4),
        Page(name: "Dhol", description: "This double-headed drum is widely used in Punjabi culture, especially in Bhangra music and dance. It is an integral part of Punjabi celebrations and its hype beats have been recognized for bringing unique energy into many Bollywood films.", imageUrl: "Dhol", tag: 5),
        Page(name: "Mrindagam", description: "A percussion instrument with a wooden barrel-shaped body with two drumheads. It's used in Carnatic classical music and is considered to be one of the oldest percussion instruments in India.", imageUrl: "Mrindagam", tag: 6),
        Page(name: "Om", description: "Indian prayers that sound like songs and chants, such as the Gayatri Mantra and Om Namah Shivaya, have deep historical and cultural significance in Hinduism and other Indian religions. These prayers are believed to have a powerful spiritual impact, and singing or chanting them is considered a form of devotion and a way to connect with the divine.", imageUrl: "Om", tag: 7),
        Page(name: "Tala", description: "Also known as 'manjira' or (mini) 'hand cymbals', talas are an important part of Indian classical music because they help to create a sense of unity throughout any performance by maintaing the rhythm. Two cymbals, usually made of brass or bronze, are struck together to produce a bright, metallic sound in devotional music, folk music, and dance.", imageUrl: "Tala", tag: 8),
        Page(name: "Bansuri", description: "A bamboo flute with six or seven holes, commonly used in both Hindustani and Carnatic classical music traditions.", imageUrl: "Bansuri", tag: 9),
        Page(name: "Fusion", description: "The fusion of trap music and Indian music has become increasingly popular in recent years, as artists blend traditional Indian instruments and melodies with trap beats and production techniques. This fusion has created a new sound that appeals to younger generations and promotes cultural exchange and diversity in music.", imageUrl: "Fusion", tag: 10),
           Page(name: "Surpeti", description: "The Surpeti, AKA, the Shruti box, is a traditional Indian instrument that produces a continuous drone sound, used to provide a reference pitch for singers and instrumentalists to tune their instruments in the background. It is an essential tool for Indian musicians and is widely used in classical music performances and practices.", imageUrl: "Surpeti", tag: 11),
        Page(name: "Shankha", description: "The Shankha, or conch shell of a snail, is regarded as auspicious to the Hindu religion. It is involved in many mythologies and is blown to initiate ceremonies or prayers.", imageUrl: "Shankha", tag: 12),
        Page(name: "Ragas", description: "Ragas are a set of specific notes and melodic patterns that evoke different moods and emotions. Its rich history dates back thousands of years and is considered to be the backbone of Indian classical music, with many popular varieties in the US such as Carnatic ragas.", imageUrl: "Ragas", tag: 13),
                Page(name: "Swaras", description: "Similar to solfège, these 7 music notes make up the octave called saptak. These make up the traditional classical melodies and each of the note names references a deity.", imageUrl: "Swaras", tag: 14),
        Page(name: "Moving On!", description: "Click on the individual colored buttons to listen to a looped sound. Add sound effects and click on multiple buttons to create layers of a song. Hit the red record button to record your final song and save it!", imageUrl: "Next", tag: 15),
        // EXPLORE PAGE
          Page(name: "Time to explore!", description: "Through this experience users are exposed to the deeper meaning to sounds. The next time you listen to songs, stop and wonder about the culture, people, and story it carries.", imageUrl: "", tag: 16),
    ]
}

// Credits: My research on the instruments and music styles have come from my family and Encyclopaedia Britannica. I've used the swift app template for Sound Pad. My app uses unique Indian instruments and sounds. However, finding such sounds authentically within the time constraints of finding this challenge within 1 week was difficult. To best represent Indian culture, I turned to royalty and copyright free music loops from Pixabay. The following is a full list of each loop used in the app.

//Sitar-
//Music by ShidenBeatsMusic from Pixabay
//Music by ShidenBeatsMusic from Pixabay
//Music by NourishedByMusic from Pixabay

//Tabla-
//Music by @bineleyas from Pixabay

//Dhol-
//Music by MarshallB from Pixabay
//Music by rushikeshkhilare from Pixabay
//Music by SergeQuadrado from Pixabay

//Laugh-
//Music by Roshan_Cariappa from Pixabay

//Bansuri-
//Music by holdi2017 from Pixabay
//Music by kmacleod from Pixabay

//Om-
//Music by Krishnananda108 from Pixabay

//Tala-
//Music by KamaleshSiddu from Pixabay

//Fusion-
//Music by RoyaltyFreeMusic from Pixabay

//In order to fit the 25 MB limit, I had to shorten the artists’ loops using GarageBand. 


