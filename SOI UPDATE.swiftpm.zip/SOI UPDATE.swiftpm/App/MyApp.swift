import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ZStack{
                BackgroundView()
                IntroView()
                    .previewInterfaceOrientation(.landscapeRight)
            }
        }
        // }
        //ContentView()
        // .previewInterfaceOrientation(.landscapeRight)
    }
}
